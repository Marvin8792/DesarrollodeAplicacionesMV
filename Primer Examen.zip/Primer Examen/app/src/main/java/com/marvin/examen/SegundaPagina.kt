package com.marvin.examen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SegundaPagina : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segunda_pagina)
    }
}